<template>
    <footer id="office-footer" :class="{ footer: true, fixed: $route.name == 'download-code' }">
        <div class="footer_pc">
            <div class="footer__pic container">
                <h3>选择即构</h3>
                <p>每月10000分钟免费</p>
                <a href="https://console.zego.im/acount/register" target="_blank" class="apply">立即试用</a>
            </div>
            <div class="footer__container container">
                <div class="footer__introduce">
                    <h3 class="title">
                        <div class="icon icon-logo"></div>
                    </h3>

                    <div class="content">
                        <div class="content">
                            <p>电话/微信：189-3893-7493</p>
                            <p>QQ：3485426954</p>
                            <p>市场合作 ：market@zego.im</p>
                        </div>
                    </div>

                    <ul class="menu-list">
                        <li class="menu-list__item service">
                            微信客服号
                            <div class="qrcode"></div>
                        </li>
                        <li class="menu-list__item subscribe">
                            微信订阅号
                            <div class="qrcode"></div>
                        </li>
                    </ul>
                </div>

                <div class="footer__info">
                    <div v-for="info of infos" :key="info.id" :class="info.id" class="info-item">
                        <h3 class="title" @click="info.active = !info.active">
                            {{ info.name }}
                            <div :class="info.active ? 'icon-arrow-up' : 'icon-arrow-down'" class="icon"></div>
                        </h3>

                        <ul :class="{ 'menu-list--active': info.active }" class="menu-list">
                            <template v-for="(child, index) of info.children">
                                <li v-if="child.html" :key="index" class="menu-list__item">
                                    {{ child.html }}
                                </li>

                                <li v-else :key="index" class="menu-list__item">
                                    <a :href="child.href">{{ child.text }}</a>
                                </li>
                            </template>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="footer__copyright">
                <div class="menu-wrapper">
                    <span class="menu-title">热门场景：</span>
                    <ul class="menu-list">
                        <li v-for="(link, index) of links" :key="index" class="menu-list__item">
                            <a :href="link.href" target="_blank">{{ link.name }}</a>
                        </li>
                    </ul>
                </div>

                <p class="copyright">
                    即构科技&nbsp;版权所有&nbsp;&nbsp;
                    <a href="http://www.beian.miit.gov.cn" target="_blank">粤ICP备15113647号 </a>&nbsp;&copy;2018-{{
                        new Date().getFullYear() + 1
                    }}
                </p>
            </div>
        </div>
        <div class="footer_m">
            <section class="pic_img">
                <h1>选择即构<br /><span>每月10000分钟免费</span></h1>
                <a href="https://console.zego.im/acount/register" class="apply">立即试用</a>
            </section>
            <section class="connection container">
                <div class="connect-item phone">
                    <img src="../assets/img/nav/foot/phone.png" alt="phone" class="icon" />
                    <a class="detail" href="tel://189 3893 7493">
                        <span class="title">电话/微信</span> <br />
                        <span class="text">189 3893 7493</span>
                    </a>
                </div>
                <div class="connect-item email">
                    <img src="../assets/img/nav/foot/email.png" alt="email" class="icon" />
                    <a class="detail" href="mailto:market@zego.im">
                        <span class="title">市场合作</span><br />
                        <span class="text">market@zego.im</span>
                    </a>
                </div>
            </section>
            <section class="communication container">
                <ul class="menu-list">
                    <li class="menu-item-wrapper">
                        <div
                            v-click-outside="hideService"
                            :class="{ 'menu-item': true, service: true, show: isShowService }"
                            @click="showService"
                        >
                            <span class="icon service"></span>
                            <div class="qrcode">
                                <div class="title">“售前支持@ZEGO”客服号</div>
                                <img src="../assets/img/nav/foot/service.png" alt="service" />
                            </div>
                        </div>
                        <span class="icon-name">微信客服号</span>
                    </li>
                    <li class="menu-item-wrapper">
                        <div
                            v-click-outside="hide"
                            :class="{
                                'menu-item': true,
                                wechat: true,
                                show: isShowSubscribe,
                            }"
                            @click="showSubscribe"
                        >
                            <span class="icon wechat"></span>
                            <div class="qrcode">
                                <div class="title">“即构科技ZEGO”订阅号</div>
                                <img src="../assets/img/nav/foot/subscribe.png" alt="subscribe" />
                            </div>
                        </div>
                        <span class="icon-name">微信订阅号</span>
                    </li>
                    <li class="menu-item-wrapper">
                        <div
                            v-clipboard:copy="message"
                            v-clipboard:success="onCopy"
                            v-clipboard:error="onError"
                            :class="{ 'menu-item': true, qq: true, show: isShowQQ }"
                        >
                            <span class="icon qq"></span>
                            <div class="qrcode">
                                <div class="title">QQ 号已复制到剪切板</div>
                                <div class="text">3485426954</div>
                            </div>
                        </div>
                        <span class="icon-name">QQ</span>
                    </li>

                    <!-- <li v-for="(item, iK) in communications" :key="iK" class="menu-item">
            <span :class="'icon ' + item"></span>
          </li> -->
                </ul>
            </section>
            <section class="copyright container">
                <span class="logo"></span>
                <p>
                    <a href="http://www.beian.miit.gov.cn" target="_blank"
                        >&copy;2018-2020&nbsp;即构科技&nbsp;版权所有&nbsp;&nbsp;粤ICP备15113647号&nbsp;
                    </a>
                </p>
            </section>
        </div>
    </footer>
</template>

<script lang="ts">
import { Vue, Component } from 'vue-property-decorator';
import ClickOutside from 'vue-click-outside';
import { Route } from 'vue-router';

interface WithRoute {
    $route: Route;
}
@Component({
    directives: { ClickOutside },
})
export default class ZFooter extends Vue implements WithRoute {
    $route!: Route;
    isShowSubscribe = false;
    isShowService = false;
    isShowQQ = false;
    message = '3485426954';
    infos = [
        {
            id: 'product',
            name: '产品',
            active: false,
            children: [
                {
                    text: '互动视频',
                    href: 'https://www.zego.im/html/product/interaction-live.html',
                },
                {
                    text: '实时语音',
                    href: 'https://www.zego.im/html/product/realtime-voice.html',
                },
                {
                    text: '语聊房',
                    href: 'javascript:void(0)',
                },
                {
                    text: '视频双录',
                    href: 'javascript:void(0)',
                },
                {
                    text: 'TalkLine',
                    href: 'https://www.talkline.cn',
                },
            ],
        },
        {
            id: 'plan',
            name: '解决方案',
            active: false,
            children: [
                {
                    text: '互动视频',
                    href: 'https://www.zego.im/html/solution/live-solution.html',
                },
                {
                    text: '互动语音',
                    href: 'https://www.zego.im/html/solution/live-solution.html',
                },
                // {
                //   text: '视频电话',
                //   href: 'javascript:void(0)'
                // },
                // {
                //   text: '视频会议',
                //   href: 'https://www.zego.im/html/solution/meeting-solution.html'
                // },
                {
                    text: '金融双录',
                    href: 'javascript:void(0)',
                },
                {
                    text: '在线教育',
                    href: 'https://www.zego.im/html/solution/edu-solution.html',
                },
                {
                    text: '直播出海',
                    href: 'javascript:void(0)',
                },
            ],
        },
        {
            id: 'developer',
            name: '开发者中心',
            active: false,
            children: [
                {
                    text: '文档中心',
                    href: 'https://doc.zego.im/',
                },
                {
                    text: '下载区',
                    href: 'https://doc.zego.im/download/sdk',
                },
                {
                    text: 'FAQ',
                    href: 'https://doc.zego.im/CN/487.html',
                },
                {
                    text: '技术社区',
                    href: 'javascript:void(0)',
                },
            ],
        },
        {
            id: 'about',
            name: '了解即构',
            active: false,
            children: [
                {
                    text: '关于即构',
                    href: 'https://www.zego.im/html/about/about-zego.html',
                },
                {
                    text: '媒体报道',
                    href: 'https://www.zego.im/article/category/%E5%AA%92%E4%BD%93%E6%8A%A5%E9%81%93',
                },
                {
                    text: '技术进展',
                    href: 'https://www.zego.im/article/category/%E6%8A%80%E6%9C%AF%E8%BF%9B%E5%B1%95',
                },
                {
                    text: '隐私政策',
                    href: 'https://www.zego.im/privacy',
                },
            ],
        },
    ];
    links = [
        // {
        //     name: '热门场景',
        //     href: '#',
        // },
        {
            name: 'AI教育',
            href: 'https://doc.zego.im/CN/668.html',
        },
        {
            name: 'KTV合唱',
            href: 'https://doc.zego.im/CN/414.html',
        },
        {
            name: '游戏直播',
            href: 'https://doc.zego.im/CN/443.html',
        },
        {
            name: '游戏语音',
            href: 'https://doc.zego.im/CN/438.html',
        },
        {
            name: '视频直播',
            href: 'https://doc.zego.im/CN/378.html',
        },
        {
            name: '语音通话',
            href: 'https://doc.zego.im/CN/404.html',
        },
        {
            name: '语聊房',
            href: 'https://doc.zego.im/CN/646.html',
        },
        {
            name: '会议',
            href: 'https://www.talkline.cn/',
        },
    ];
    // communications = ['wechat', 'qq', 'book', 'avatar']
    mounted() {
        // console.log('route', this.$route)
    }
    showSubscribe() {
        console.log('showSubscribe');
        this.isShowSubscribe = true;
    }
    hide() {
        // console.log('showSubscribe')
        this.isShowSubscribe = false;
    }
    showService() {
        console.log('showSubscribe');
        this.isShowService = true;
    }
    hideService() {
        // console.log('showSubscribe')
        this.isShowService = false;
    }
    onCopy() {
        console.log('copy');
        this.isShowQQ = true;
        setTimeout(() => {
            this.isShowQQ = false;
        }, 2000);
    }
    onError() {
        console.log('error');
    }
}
</script>

<style lang="scss" scoped>
.footer_pc {
    height: 823px;
    padding-top: 90px;
}
.footer_m {
    display: none;
}
.footer {
    position: relative;
    background-color: #161c28;

    .footer__pic {
        display: block;
        width: 100%;
        margin: auto;
        height: 330px;
        background: url(../assets/img/bg/foot.png);
        background-size: cover;
        padding-left: 750px;
        padding-top: 68px;
        h3 {
            font-size: 40px;
            line-height: 1;
            margin-bottom: 22px;
        }
        p {
            font-size: 34px;
            margin-bottom: 68px;
        }
        .apply {
            display: inline-block;
            width: 170px;
            height: 46px;
            background: rgba(0, 68, 255, 1);
            border-radius: 4px;
            color: #fff;
            line-height: 46px;
            text-align: center;
            &:hover,
            &:active {
                background: #002bff;
            }
        }
    }

    .footer__container {
        display: flex;
        justify-content: space-between;
        margin: 70px auto 0;

        .footer__introduce {
            color: #fff;

            .title {
                display: flex;
                align-items: center;
                font-size: 28px;
                color: #fff;

                .icon-logo {
                    width: 142px;
                    height: 26px;
                    background: url(../assets/img/nav/f-logo.png);
                    background-size: 100%;
                }
            }

            .content {
                margin-top: 28px;
                margin-bottom: 37px;
                max-width: 20em;
                font-size: 14px;
                color: #fff;
                opacity: 0.65;
                line-height: 24px;
                // &:hover {
                //   opacity: 1;
                // }
            }

            .menu-list {
                display: flex;

                .menu-list__item {
                    opacity: 0.65;
                    &.service,
                    &.subscribe {
                        position: relative;

                        .qrcode {
                            position: absolute;
                            right: 0;
                            bottom: 130%;
                            left: 0;
                            // margin: 0 auto;
                            width: 70px;
                            height: 75px;
                            background-position: center;
                            background-size: contain;
                            background-repeat: no-repeat;
                            visibility: hidden;
                        }

                        &:hover {
                            opacity: 1;
                            .qrcode {
                                visibility: visible;
                            }
                        }
                    }

                    &.service {
                        padding-right: 15px;

                        .qrcode {
                            background-image: url('../assets/img/common/img-service.png');
                        }
                    }

                    &.subscribe {
                        // padding-left: 7px;
                        // border-left: 1px solid currentColor;

                        .qrcode {
                            background-image: url('../assets/img/common/img-subscribe.png');
                        }
                    }
                }
            }
        }

        .footer__info {
            display: flex;
            color: #fff;

            div {
                .title {
                    margin-bottom: 18px;
                    color: #fff;

                    .icon {
                        display: none;
                    }
                }

                .menu-list > .menu-list__item {
                    padding-left: 3em;
                    text-indent: -3em;
                    line-height: 1;
                    margin-bottom: 15px;

                    a {
                        color: inherit;
                        opacity: 0.5;
                        &:hover {
                            opacity: 1;
                        }
                    }
                }
            }

            div + div {
                margin-left: 60px;
            }
        }
    }

    .footer__copyright {
        position: absolute;
        right: 0;
        bottom: 0;
        left: 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 20px 0;
        border-top: 1px solid #464646;

        .menu-wrapper {
            display: flex;
            .menu-title {
                color: #fff;
                opacity: 0.65;
            }
        }

        .menu-list {
            display: flex;
            margin-bottom: 13px;

            .menu-list__item {
                min-width: 100px;
                text-align: center;
                color: #fff;

                > a {
                    color: inherit;
                    opacity: 0.65;

                    &:hover {
                        opacity: 1;
                    }
                }
                // &:first-child {
                //     a {
                //         &:hover {
                //             opacity: 0.65;
                //             cursor: inherit;
                //         }
                //     }
                // }
            }

            .menu-list__item + .menu-list__item {
                border-left: 1px solid #999;
            }
        }

        .copyright {
            font-size: 12px;
            color: #fff;
            opacity: 0.4;
            a {
                font-size: 12px;
                color: #fff;
                // opacity: 0.4;
                // &:hover {
                //   opacity: 1;
                // }
            }
        }
    }
}

@media screen and (max-width: 1000px) {
    .container {
        max-width: 6.3rem;
        margin: auto;
        padding: 0;
    }
    .footer {
        padding-top: 0.6rem;
    }
    .footer_pc {
        display: none;
    }
    .footer_m {
        display: block;
    }
    .footer_m {
        width: 100%;
        height: 9.03rem;
        .pic_img {
            margin: 0 auto;
            width: 6.3rem;
            height: 3.2rem;
            padding-top: 0.68rem;
            padding-right: 0.43rem;
            background: url(../assets/img/nav/foot_pic_m.png) no-repeat;
            background-size: 100%;
            text-align: right;
            h1 {
                font-size: 0.4rem;
                font-weight: 500;
                line-height: 1;
                color: #222;
                span {
                    display: inline-block;
                    font-size: 0.36rem;
                    margin-top: 0.18rem;
                }
            }
            .apply {
                margin-top: 0.4rem;
                display: inline-block;
                width: 1.62rem;
                height: 0.66rem;
                line-height: 0.66rem;
                color: #fff;
                // border: 0.02rem solid rgba(43, 33, 33, 0.2);
                border-radius: 0.08rem;
                background: #0044ff;
                text-align: center;
            }
        }
    }
    .connection {
        margin-top: 0.6rem;
        height: 1.28rem;
        border: 1px solid rgba(43, 51, 67, 1);
        border-radius: 0.12rem;
        display: flex;
        .connect-item {
            flex: 1;
            height: 100%;
            padding-left: 0.45rem;
            display: flex;
            align-items: center;
            .icon {
                display: inline-block;
                width: 0.36rem;
                height: 0.36rem;
            }
            .detail {
                margin-left: 0.24rem;
                .title {
                    font-size: 0.28rem;
                    color: #b1bacb;
                    display: inline-block;
                    margin-bottom: 0.1rem;
                }
                .text {
                    margin-top: 0.19rem;
                    font-size: 0.24rem;
                    color: #798499;
                }
            }
            &.phone {
                border-right: 1px solid rgba(43, 51, 67, 1);
            }
        }
    }
    .communication {
        margin-top: 0.6rem;
        .menu-list {
            display: flex;
            justify-content: space-between;
            padding: 0 0.62rem;

            .menu-item-wrapper {
                width: 1.2rem;
                display: flex;
                flex-direction: column;
                align-items: center;
                .icon-name {
                    margin-top: 0.17rem;
                    font-size: 0.24rem;
                    color: #5b6476;
                }
            }
            .menu-item {
                width: 0.88rem;
                height: 0.88rem;
                background-color: #1b222f;
                border-radius: 50%;
                display: flex;
                justify-content: center;
                align-items: center;
                .icon {
                    display: inline-block;
                    width: 0.48rem;
                    height: 0.48rem;
                    &.service {
                        background: url(../assets/img/nav/foot/w-service.png);
                        background-size: 100%;
                    }
                    &.wechat {
                        background: url(../assets/img/nav/foot/wechat-m.png);
                        background-size: 100%;
                    }
                    &.qq {
                        background: url(../assets/img/nav/foot/qq-m.png);
                        background-size: 100%;
                    }
                    &.book {
                        background: url(../assets/img/nav/foot/book.png);
                        background-size: 100%;
                    }
                    &.avatar {
                        background: url(../assets/img/nav/foot/avatar.png);
                        background-size: 100%;
                    }
                }
                &.wechat,
                &.service {
                    position: relative;
                    .qrcode {
                        position: absolute;
                        right: 0;
                        bottom: 130%;
                        left: 50%;
                        transform: translate(-50%);
                        margin: 0 auto;
                        width: 3.16rem;
                        height: 3.76rem;
                        background-color: #fff;
                        border-radius: 0.08rem;
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        visibility: hidden;
                        .title {
                            font-size: 0.2rem;
                            color: #222;
                            margin: 0.32rem auto 0.23rem;
                            font-family: 'PingFang SC';
                            letter-spacing: -1px;
                        }
                        img {
                            width: 2.64rem;
                            height: 2.64rem;
                        }
                        // background-image: url(../assets/img/nav/foot/subscribe.png);
                        // background-position: center;
                        // background-size: contain;
                        // background-repeat: no-repeat;
                        &::after {
                            position: absolute;
                            content: '';
                            display: block;
                            width: 0;
                            height: 0;
                            bottom: -0.39rem;
                            border: 0.2rem solid transparent;
                            border-top-color: #fff;
                        }
                    }
                    &.show {
                        .qrcode {
                            visibility: visible;
                        }
                    }
                }
                &.qq {
                    position: relative;
                    .qrcode {
                        position: absolute;
                        right: 0;
                        bottom: 130%;
                        left: 50%;
                        transform: translate(-50%);
                        margin: 0 auto;
                        width: 2.6rem;
                        height: 1.08rem;
                        background-color: #fff;
                        border-radius: 0.08rem;
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        visibility: hidden;
                        .title {
                            font-size: 0.2rem;
                            color: #222;
                            margin: 0.32rem auto 0.12rem;
                            font-family: 'PingFang SC';
                            letter-spacing: -1px;
                        }
                        .text {
                            color: #999;
                            font-size: 0.18rem;
                        }
                        // background-image: url(../assets/img/nav/foot/subscribe.png);
                        // background-position: center;
                        // background-size: contain;
                        // background-repeat: no-repeat;
                        &::after {
                            position: absolute;
                            content: '';
                            display: block;
                            width: 0;
                            height: 0;
                            bottom: -0.39rem;
                            border: 0.2rem solid transparent;
                            border-top-color: #fff;
                        }
                    }
                    &.show {
                        .qrcode {
                            visibility: visible;
                        }
                    }
                }
            }
        }
    }
    .copyright {
        text-align: center;
        margin-top: 0.6rem;
        .logo {
            position: relative;
            display: inline-block;
            width: 1.84rem;
            height: 0.32rem;
            background: url(../assets/img/nav/foot/logo-m.png);
            background-size: 100%;
            &::before {
                position: absolute;
                left: -120%;
                top: 50%;
                content: '';
                width: 1.75rem;
                height: 0.02rem;
                background-color: #212835;
            }
            &::after {
                position: absolute;
                left: 120%;
                top: 50%;
                content: '';
                width: 1.75rem;
                height: 0.02rem;
                background-color: #212835;
            }
        }
        p {
            margin-top: 0.32rem;
            a {
                font-size: 0.2rem;
                color: #3f4653;
            }
        }
    }
}
</style>
